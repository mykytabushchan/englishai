import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'EnglishAI — Learn English with AI',
  description: 'Master English grammar, vocabulary and professional communication with AI-powered exercises',
  openGraph: {
    title: 'EnglishAI',
    description: 'Learn English with AI-generated exercises',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;1,9..40,400&display=swap" rel="stylesheet" />
      </head>
      <body className="bg-bg text-white font-dm antialiased">{children}</body>
    </html>
  )
}
